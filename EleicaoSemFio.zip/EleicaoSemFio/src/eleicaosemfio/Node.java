/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eleicaosemfio;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author Gustavo
 */
public class Node {
    private final int id;
    private final double weight;
    private final int[] adjs;
    
    private int parent;
    private final HashSet<Integer> children;
    
    private int reportCount;
    
    private int bestId;
    private double bestWeight;
    
    // Client socket writers
    private BufferedWriter[] writers;

    public Node(int id, boolean isRoot, double weight, int[] adjs) throws InterruptedException, IOException {
        this.id = id;
        this.weight = weight;
        this.adjs = adjs;
        
        if (isRoot)
            this.parent = id;
        else
            this.parent = -1;        
        this.children = new HashSet<>();
        
        for (int adj : adjs)
            children.add(adj);
        
        this.reportCount = 0;
        
        this.bestId = id;
        this.bestWeight = weight;
    }

    public synchronized int getId() {
        return id;
    }

    public synchronized int getParent() {
        return parent;
    }

    public synchronized void setParent(int parent) {
        this.parent = parent;
        
        this.removeFromChildren(parent);
    }
    
    public synchronized  void initServer() {
        new ServerThread(this).start();
    }
    
    public synchronized  void initClients() throws IOException {
        Socket[] sockets = new Socket[EleicaoSemFio.NUM_NODES];
        for (int i = 0; i < EleicaoSemFio.NUM_NODES; ++i)
            sockets[i] = new Socket("localhost", 3031 + i);
        
        OutputStreamWriter[] streams = new OutputStreamWriter[EleicaoSemFio.NUM_NODES];
        for (int i = 0; i < EleicaoSemFio.NUM_NODES; ++i)
            streams[i] = new OutputStreamWriter(sockets[i].getOutputStream());
        
        writers = new BufferedWriter[EleicaoSemFio.NUM_NODES];
        for (int i = 0; i < EleicaoSemFio.NUM_NODES; ++i)
            writers[i] = new BufferedWriter(streams[i]);
    }
    
    public synchronized void sendElectionMessageToAdjs() throws IOException {
        synchronized (System.out) {
            System.out.println("Mandei election para meus não parent");
        }
        
        for (int i = 0; i < adjs.length; ++i) {
            int adj = adjs[i];
            
            if (adj == parent)
                continue;
            
            // Write message
            writers[adj].write(Integer.toString(id) + "\n");
            writers[adj].write(Integer.toString(EleicaoSemFio.MESSAGE_ELECTION) + "\n");

            // Flush output stream
            writers[adj].flush();
        }
    }

    public synchronized void sendOKMessage(int sourceId) throws IOException {
        synchronized (System.out) {
            System.out.println("Enviei OK para " + sourceId);
        }
                    
        // Write message
        writers[sourceId].write(Integer.toString(id) + "\n");
        writers[sourceId].write(Integer.toString(EleicaoSemFio.MESSAGE_OK) + "\n");

        // Flush output stream
        writers[sourceId].flush();
    }

    public synchronized int getNumChildren() {
        return children.size();
    }
    
    public synchronized void removeFromChildren(int id) {
        synchronized (System.out) {
            System.out.print("Removi " + id + " dos children (");
            for (int i : children)
                System.out.print(i + ", ");
            System.out.println(")");
        }
        
        children.remove(id);
    }

    public synchronized void sendReportToParent() throws IOException {
        synchronized (System.out) {
            System.out.println("Mandei report para meu parent com (Id: " + bestId + " e Peso: " + bestWeight + ")");
        }
        
        // Write message
        writers[parent].write(Integer.toString(id) + "\n");
        writers[parent].write(Integer.toString(EleicaoSemFio.MESSAGE_REPORT) + "\n");
        
        // Best infos
        writers[parent].write(Integer.toString(bestId) + "\n");
        writers[parent].write(Double.toString(bestWeight) + "\n");

        // Flush output stream
        writers[parent].flush();
    }

    public synchronized void receiveReport(int bestId, double bestWeight) throws IOException {
        ++this.reportCount;
        
        if (bestWeight < this.bestWeight) {
            this.bestId = bestId;
            this.bestWeight = bestWeight;
        }
        if (reportCount == children.size()) {
            synchronized (System.out) {
                System.out.println("Todos os reports foram recebidos");
            }

            if (parent != id)
                sendReportToParent();
            if (parent == id) {
                synchronized (System.out) {
                    System.out.println("Melhor de todos (Id: " + this.bestId + ", Peso: " + this.bestWeight + ")");
                }
            }
        }
    }
}
