/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eleicaosemfio;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author Gustavo
 */
public class Node {
    private final int id;
    private final boolean isRoot;
    private final double weight;
    private final int[] adjs;
    
    private int parent;
    private final HashSet<Integer> children;
    
    private int reportCount;
    
    private int bestId;
    private double bestWeight;
    
    // Client socket writers
    private BufferedWriter[] writers;

    public Node(int id, boolean isRoot, double weight, int[] adjs) throws InterruptedException, IOException {
        this.id = id;
        this.isRoot = isRoot;
        this.weight = weight;
        this.adjs = adjs;
        
        this.parent = -1;        
        this.children = new HashSet<>();
        
        for (int adj : adjs)
            children.add(adj);
        
        this.reportCount = 0;
        
        this.bestId = id;
        this.bestWeight = weight;
        
        initServer();
        
        Thread.sleep(1000);
        
        initClients();
        
        Thread.sleep(1000);
        
        if (isRoot)
            sendElectionMessageToAdjs();
    }

    public int getId() {
        return id;
    }

    public int getParent() {
        return parent;
    }

    public void setParent(int parent) {
        this.parent = parent;
    }
    
    private void initServer() {
        new ServerThread(this).start();
    }
    
    private void initClients() throws IOException {
        Socket[] sockets = new Socket[EleicaoSemFio.NUM_NODES];
        for (int i = 0; i < EleicaoSemFio.NUM_NODES; ++i)
            sockets[i] = new Socket("localhost", 3031 + i);
        
        OutputStreamWriter[] streams = new OutputStreamWriter[EleicaoSemFio.NUM_NODES];
        for (int i = 0; i < EleicaoSemFio.NUM_NODES; ++i)
            streams[i] = new OutputStreamWriter(sockets[i].getOutputStream());
        
        writers = new BufferedWriter[EleicaoSemFio.NUM_NODES];
        for (int i = 0; i < EleicaoSemFio.NUM_NODES; ++i)
            writers[i] = new BufferedWriter(streams[i]);
    }
    
    public synchronized void sendElectionMessageToAdjs() throws IOException {
        for (int i = 0; i < adjs.length; ++i) {
            int adj = adjs[i];
            
            // Write message
            writers[adj].write(Integer.toString(id) + "\n");
            writers[adj].write(Integer.toString(EleicaoSemFio.MESSAGE_ELECTION) + "\n");

            // Flush output stream
            writers[adj].flush();
        }
    }

    void sendOKMessage(int sourceId) throws IOException {
        // Write message
        writers[sourceId].write(Integer.toString(id) + "\n");
        writers[sourceId].write(Integer.toString(EleicaoSemFio.MESSAGE_OK) + "\n");

        // Flush output stream
        writers[sourceId].flush();
    }

    int getNumChildren() {
        return children.size();
    }
    
    public void removeFromChildren(int id) {
        children.remove(id);
    }

    void sendReportToParent() throws IOException {
        // Write message
        writers[parent].write(Integer.toString(id) + "\n");
        writers[parent].write(Integer.toString(EleicaoSemFio.MESSAGE_REPORT) + "\n");
        
        // Best infos
        writers[parent].write(Integer.toString(bestId) + "\n");
        writers[parent].write(Double.toString(bestWeight) + "\n");

        // Flush output stream
        writers[parent].flush();
    }

    void receiveReport(int bestId, double bestWeight) throws IOException {
        ++this.reportCount;
        
        if (bestWeight < this.bestWeight) {
            this.bestId = bestId;
            this.bestWeight = bestWeight;
        }
        
        if (reportCount == children.size())
            sendReportToParent();
    }
}
