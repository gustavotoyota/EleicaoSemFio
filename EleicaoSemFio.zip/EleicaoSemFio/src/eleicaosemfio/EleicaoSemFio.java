/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eleicaosemfio;

import java.io.IOException;

/**
 *
 * @author Gustavo
 */
public class EleicaoSemFio {
    public static int NUM_NODES = 10;
    public static int[][] ADJS = {
        {1, 2},
        {0, 2, 3, 4},
        {0, 1, 3},
        {1, 2, 4, 5, 6},
        {1, 3, 5, 7},
        {3, 4, 6, 7},
        {3, 5, 7, 8},
        {4, 5, 6, 8, 9},
        {6, 7, 9},
        {7, 8}
    };
    public static double[] WEIGHTS = {0.35, 5.23, 2.26, 3.53, 7.73, 3.43, 2.34, 6.78, 2.32, 7.8};
    
    public static int MESSAGE_ELECTION = 0;
    public static int MESSAGE_OK = 1;
    public static int MESSAGE_REPORT = 2;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, IOException {
        int nodeId = Integer.parseInt(args[0]);
        boolean isRoot = Boolean.parseBoolean(args[1]);
        
        Node node = new Node(nodeId, isRoot, WEIGHTS[nodeId], ADJS[nodeId]);
    }   
}
