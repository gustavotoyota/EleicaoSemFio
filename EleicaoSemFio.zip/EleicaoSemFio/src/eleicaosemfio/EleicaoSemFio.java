/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eleicaosemfio;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Gustavo
 */
public class EleicaoSemFio {
    public static int NUM_NODES = 10;
    public static int[][] ADJS = {
        {1, 2},
        {0, 2, 3, 4},
        {0, 1, 3},
        {1, 2, 4, 5, 6},
        {1, 3, 5, 7},
        {3, 4, 6, 7},
        {3, 5, 7, 8},
        {4, 5, 6, 8, 9},
        {6, 7, 9},
        {7, 8}
    };
    public static double[] WEIGHTS = {0.35, 5.23, 2.26, 3.53, 7.73, 3.43, 2.34, 6.78, 2.32, 7.8};
    
    /*public static int NUM_NODES = 3;
    public static int[][] ADJS = {
        {1, 2},
        {0, 2},
        {0, 1}
    };
    public static double[] WEIGHTS = {0.35, 5.23, 2.26};*/
    
    public static final int MESSAGE_ELECTION = 0;
    public static final int MESSAGE_OK = 1;
    public static final int MESSAGE_REPORT = 2;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, IOException {
        int nodeId = Integer.parseInt(args[0]);
        boolean isRoot = Boolean.parseBoolean(args[1]);
        
        /*System.out.print("Id: ");
        Scanner scanner = new Scanner(System.in);
        int nodeId = scanner.nextInt();
        
        boolean isRoot = scanner.nextBoolean();
        scanner.nextLine();*/
        
        Node node = new Node(nodeId, isRoot, WEIGHTS[nodeId], ADJS[nodeId]);
        
        node.initServer();
        
        Thread.sleep(1000);
        
        // Wait for all servers to be initialized
        /*System.out.println("Esperando inicialização dos servidores.");
        System.out.print("Digite enter para continuar.");
        scanner.nextLine();*/
        
        node.initClients();
        
        Thread.sleep(1000);
        
        if (isRoot)
            node.sendElectionMessageToAdjs();
    }   
}
