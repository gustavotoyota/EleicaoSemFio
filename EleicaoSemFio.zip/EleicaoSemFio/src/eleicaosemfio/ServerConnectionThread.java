/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eleicaosemfio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gustavo
 */
public class ServerConnectionThread extends Thread {
    private final Socket socket;
    private final Node node;
    
    private BufferedReader bufferedReader;
            
    public ServerConnectionThread(Socket socket, Node node) {
        this.socket = socket;
        this.node = node;
    }
    
    private void receiveMessage() throws IOException {
        // Receive request
        // 0 - Eleicao
        // 1 - OK
        // 2 - Report
        int sourceId = Integer.parseInt(bufferedReader.readLine());
        int messageType = Integer.parseInt(bufferedReader.readLine());
        
        synchronized (node) {
            switch (messageType) {
            case EleicaoSemFio.MESSAGE_ELECTION:
                synchronized (System.out) {
                    System.out.println("Recebi msg de eleição de " + sourceId);
                }
                
                if (node.getParent() == -1) {
                    node.setParent(sourceId);
                    
                    synchronized (System.out) {
                        System.out.println("Settei o parent para " + sourceId);
                    }
                    
                    node.sendElectionMessageToAdjs();
                } else
                    node.sendOKMessage(sourceId);
                break;
            case EleicaoSemFio.MESSAGE_OK:
                synchronized (System.out) {
                    System.out.println("Recebi OK de " + sourceId);
                }
                
                node.removeFromChildren(sourceId);
                if (node.getNumChildren() == 0) {
                    synchronized (System.out) {
                        System.out.println("Zero filhos, sou nó folha");
                    }
                    
                    node.sendReportToParent();
                }
                break;
            case EleicaoSemFio.MESSAGE_REPORT:
                int bestId = Integer.parseInt(bufferedReader.readLine());
                double bestWeight = Double.parseDouble(bufferedReader.readLine());
        
                synchronized (System.out) {
                    System.out.println("Recebi report com bestId " + bestId + " e peso " + bestWeight);
                }
                
                node.receiveReport(bestId, bestWeight);
                break;
            }
        }
    }
    
    @Override
    public void run() {
        try {
            InputStreamReader streamReader = new InputStreamReader(socket.getInputStream());
            bufferedReader = new BufferedReader(streamReader);
            
            while (this.isAlive())
                receiveMessage();
        } catch (IOException ex) {
            Logger.getLogger(ServerConnectionThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
